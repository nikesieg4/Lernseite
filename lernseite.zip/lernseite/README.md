# Lernseite

Eine kleine Lernplattform für interaktive Lerneinheiten (HTML-Simulationen, Quizze …).
Schüler/innen melden sich **mit ihrem IServ-Konto** an, die Lernseite speichert, welche
Lerneinheiten sie erledigt haben, und Lehrkräfte sehen den Fortschritt ihrer Klassen.

- **Anmeldung über IServ (Single-Sign-On).** Das Passwort wird nur bei IServ eingegeben.
  Die Lernseite bekommt Benutzername, Name, E-Mail und Rollen, aber nie das Passwort.
- **Schülerliste** (CSV mit E-Mail, Name, Klasse) bestimmt, wer rein darf und in welcher Klasse er ist.
- **Lerneinheiten** sind einfach Ordner mit einer `index.html`. Neue Ordner erscheinen automatisch.
- **Fortschritt:** pro Schüler/in und Lerneinheit, Übersicht als Tabelle pro Klasse.

---

## 1. Ausprobieren auf dem eigenen Rechner

Voraussetzung: [Node.js](https://nodejs.org) 20 oder neuer.

```bash
npm install
cp .env.example .env
```

In `.env` zum Testen setzen:

```
BASE_URL=http://localhost:3000
DEV_LOGIN=true
ROSTER_REQUIRED=false
```

Dann starten und <http://localhost:3000> öffnen:

```bash
npm start
```

Mit `DEV_LOGIN=true` gibt es einen Test-Login ohne IServ, bei dem man auch die Rolle
(Schüler/in, Lehrkraft, Admin) auswählen kann. **Im echten Betrieb muss `DEV_LOGIN=false` sein.**

---

## 2. IServ-Anmeldung einrichten (macht der IServ-Admin)

In IServ unter **Verwaltung → System → Single-Sign-On → Hinzufügen → OAuth-Client**:

| Feld | Wert |
|---|---|
| Name | z. B. `Lernseite` |
| Weiterleitungs-URI | `https://lernen.meine-schule.de/auth/callback` (eure Subdomain) |
| Vertrauenswürdig | ja (sonst muss jeder Schüler die Freigabe einmal bestätigen) |
| Scopes / Einschränkungen | **OpenID, Profil, E-Mail, Rollen** |

Danach zeigt IServ eine **Client-ID** und ein **Client-Secret**. Beides kommt in die `.env`:

```
ISERV_URL=https://meine-schule.de
ISERV_CLIENT_ID=...
ISERV_CLIENT_SECRET=...
```

Benutzte Adressen (fest eingebaut in `src/iserv.js`):

- Anmeldung: `ISERV_URL/iserv/oauth/v2/auth`
- Token: `ISERV_URL/iserv/oauth/v2/token`
- Benutzerdaten: `ISERV_URL/iserv/public/oauth/userinfo`

### Lehrkräfte und Admins

- **Lehrkraft** ist, wer in IServ eine der Rollen aus `TEACHER_ROLES` hat. Welche Rollen-IDs
  eure IServ liefert, steht nach dem ersten Login unter **/admin → Angemeldete Konten → IServ-Rollen**.
- **Admin** ist, wessen IServ-Benutzername oder E-Mail in `ADMIN_USERS` steht.
  Admins können die Schülerliste hochladen und alle Konten sehen.

---

## 3. Auf der Schul-Subdomain betreiben (Docker)

Ihr braucht einen Server (Schulserver oder gemieteter VPS) mit Docker, und die Subdomain
(z. B. `lernen.meine-schule.de`) muss per DNS auf diesen Server zeigen.

```bash
cp .env.example .env      # BASE_URL, DOMAIN, SESSION_SECRET, ISERV_… eintragen
openssl rand -hex 32      # Ausgabe als SESSION_SECRET verwenden
mkdir -p data && sudo chown 1000:1000 data
docker compose up -d --build
```

Caddy holt automatisch ein HTTPS-Zertifikat für `DOMAIN`. Die Datenbank liegt in `data/`,
die Lerneinheiten in `lessons/`. **Sichert den Ordner `data/` regelmäßig.**

Ohne Docker geht es auch: `npm install --omit=dev` und `npm start` hinter einem
Reverse-Proxy (nginx, Apache) mit HTTPS. Wichtig: der Proxy muss den `Host`-Header durchreichen.

---

## 4. Schülerliste

Unter **/admin** (nur Admins) als CSV hochladen oder einfügen, eine Zeile pro Schüler/in:

```
E-Mail;Name;Klasse
max.muster@meine-schule.de;Max Muster;10a
erika.beispiel@meine-schule.de;Erika Beispiel;10b
```

- Kopfzeile optional. Spalten werden an den Namen erkannt (`E-Mail`, `Name` oder `Vorname`/`Nachname`, `Klasse`).
- Trennzeichen `;`, `,` oder Tab. Ein IServ-Export (Benutzerliste als CSV) passt meist direkt.
- Die E-Mail muss die IServ-Adresse sein, denn die kommt beim Login von IServ zurück.
- Speichern ersetzt die ganze Liste. Bestehende Konten bekommen dabei ihre neue Klasse.
- **Keine Passwörter in die Liste schreiben.** Die braucht die Lernseite nicht.

Mit `ROSTER_REQUIRED=true` kommen nur Schüler/innen aus der Liste rein (Lehrkräfte und Admins immer).
Mit `false` darf jedes IServ-Konto rein, die Liste ordnet dann nur die Klassen zu.

---

## 5. Lerneinheiten erstellen

Jede Lerneinheit ist ein Ordner in `lessons/`:

```
lessons/
  ohmsches-gesetz/
    index.html      ← der Inhalt (beliebiges HTML/JS, auch mehrere Dateien)
    lesson.json     ← Titel, Fach, …
    bild.png        ← weitere Dateien, relativ eingebunden
```

Am einfachsten `lessons/_vorlage` kopieren. Ordnernamen nur mit Kleinbuchstaben, Ziffern und `-`.
Ordner mit `_` am Anfang werden nicht angezeigt.

`lesson.json`:

```json
{
  "title": "Ohmsches Gesetz",
  "subject": "Physik",
  "description": "Kurzer Text für die Übersicht",
  "minutes": 15,
  "order": 10,
  "classes": ["10a", "10b"],
  "hidden": false
}
```

- `subject` gruppiert die Übersicht, `order` sortiert innerhalb des Fachs.
- `classes` (optional): nur diese Klassen sehen die Einheit. Weglassen oder `null` = alle.
- `hidden: true` blendet die Einheit aus.

**Fortschritt melden:** Wenn eine Einheit geschafft ist, ruft sie

```js
window.parent.postMessage({ type: 'lernseite:erledigt' }, '*');
```

auf. Sonst können Schüler/innen oben auf „Als erledigt markieren“ klicken.
Die Diodenschaltung meldet sich z. B. als erledigt, sobald alle vier Schalterstellungen ausprobiert wurden.

> Lerneinheiten laufen mit den Rechten der Lernseite. Legt daher nur Dateien von
> vertrauenswürdigen Personen (Lehrkräfte, Admins) in `lessons/`.

---

## 6. Datenschutz (bitte mit der Schulleitung / dem DSB klären)

Gespeichert werden: IServ-Benutzername, Name, E-Mail, Klasse, IServ-Rollen, letzter Login
und welche Lerneinheit wann erledigt wurde. Keine Passwörter, keine Tracking-Dienste,
keine externen Skripte (die Seite lädt nichts von fremden Servern).
Der Login-Cookie ist technisch notwendig und läuft nach 12 Stunden ab.

Für den Betrieb an einer Schule braucht ihr in der Regel die Zustimmung der Schulleitung,
einen Eintrag ins Verzeichnis der Verarbeitungstätigkeiten und ggf. einen Vertrag zur
Auftragsverarbeitung mit dem Hoster. Konten entfernen geht über die Datenbank
(`DELETE FROM users WHERE username = '…'`, der Fortschritt wird mitgelöscht).

---

## Aufbau

```
server.js          Routen: Login, Übersicht, Lerneinheiten, Fortschritt, Verwaltung
src/config.js      liest .env
src/db.js          SQLite-Datenbank (data/lernseite.db)
src/iserv.js       IServ-Login (OAuth 2 mit PKCE)
src/lessons.js     liest die Ordner in lessons/
src/views.js       HTML der Seiten
public/style.css   Aussehen (hell/dunkel automatisch)
```

| Adresse | Zweck |
|---|---|
| `/` | Login bzw. Übersicht der Lerneinheiten |
| `/lektion/<name>` | Lerneinheit mit „Erledigt“-Knopf |
| `/inhalt/<name>/…` | Dateien der Lerneinheit (nur angemeldet) |
| `/admin` | Fortschritt pro Klasse, Schülerliste, Konten |
| `/api/ich` | eigene Daten und Fortschritt als JSON |
| `POST /api/fortschritt` | `{ "slug": "...", "done": true }` |
